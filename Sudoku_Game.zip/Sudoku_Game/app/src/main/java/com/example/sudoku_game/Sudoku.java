package com.example.sudoku_game;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class Sudoku extends Activity implements View.OnClickListener {
    private static final String TAG = "Sudoku";

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.main);
        findViewById(R.id.continuer_button).setOnClickListener(this);
        findViewById(R.id.nouveau_button).setOnClickListener(this);
        findViewById(R.id.about_button).setOnClickListener(this);
        findViewById(R.id.exit_button).setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.continuer_button:
                startGame(-1);
                return;
            case R.id.nouveau_button:
                openNewGameDialog();
                return;
            case R.id.about_button:
                startActivity(new Intent(this, About.class));
                return;
            case R.id.exit_button:
                finish();
                return;
            default:
                return;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings:
                startActivity(new Intent(this, Prefs.class));
                return true;
            default:
                return false;
        }
    }

    private void openNewGameDialog() {
        new AlertDialog.Builder(this).setTitle((int) R.string.new_game_title).setItems((int) R.array.difficulty, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialoginterface, int i) {
                Sudoku.this.startGame(i);
            }
        }).show();
    }

    public void startGame(int i) {
        Log.d(TAG, "clicked on " + i);
        Intent intent = new Intent(this, Game.class);
        intent.putExtra(Game.KEY_DIFFICULTY, i);
        this.startActivity(intent);
    }

    public void onPause() {
        super.onPause();
        Music.stop(this);
    }

    public void onResume() {
        super.onResume();
        Music.play(this, R.raw.main);
    }
}
