package com.example.sudoku_game;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.Array;

public class Game extends Activity {
    protected static final int DIFFICULTY_CONTINUE = -1;
    public static final int DIFFICULTY_EASY = 0;
    public static final int DIFFICULTY_HARD = 2;
    public static final int DIFFICULTY_MEDIUM = 1;
    public static final String KEY_DIFFICULTY = "org.example.sudoku_game.difficulty";
    private static final String PREF_PUZZLE = "puzzle";
    private static final String TAG = "Sudoku";
    private final String easyPuzzle = "360000000004230800000004200070460003820000014500013020001900000007048300000000045";
    private final String hardPuzzle = "009000000080605020501078000000000700706040102004000000000720903090301080000000600";
    private final String mediumPuzzle = "650000070000506000014000005007009000002314700000700800500000630000201000030000097";
    private int[] puzzle;
    private PuzzleView puzzleView;
    private final int[][][] used = ((int[][][]) Array.newInstance(int[].class, 9, 9));


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        this.puzzle = getPuzzle(getIntent().getIntExtra(KEY_DIFFICULTY, 0));
        calculateUsedTiles();
        this.puzzleView = new PuzzleView(this);
        setContentView(this.puzzleView);
        this.puzzleView.requestFocus();
        getIntent().putExtra(KEY_DIFFICULTY, -1);
    }

    private void calculateUsedTiles() {
        for (int x = 0; x < 9; x++) {
            for (int y = 0; y < 9; y++) {
                this.used[x][y] = calculateUsedTiles(x, y);
            }
        }
    }

    private int[] calculateUsedTiles(int x, int y) {
        int nused;
        int t;
        int t2;
        int t3;
        int i = 0;
        int[] c = new int[9];
        for (int i2 = 0; i2 < 9; i2++) {
            if (!(i2 == x || (t3 = getTile(i2, y)) == 0)) {
                c[t3 - 1] = t3;
            }
        }
        for (int i3 = 0; i3 < 9; i3++) {
            if (!(i3 == y || (t2 = getTile(x, i3)) == 0)) {
                c[t2 - 1] = t2;
            }
        }
        int startx = (x / 3) * 3;
        int starty = (y / 3) * 3;
        for (int i4 = startx; i4 < startx + 3; i4++) {
            for (int j = starty; j < starty + 3; j++) {
                if (!((i4 == x && j == y) || (t = getTile(i4, j)) == 0)) {
                    c[t - 1] = t;
                }
            }
        }
        int nused2 = 0;
        for (int t4 : c) {
            if (t4 != 0) {
                nused2++;
            }
        }
        int[] c1 = new int[nused2];
        int length = c.length;
        int nused3 = 0;
        while (i < length) {
            int t5 = c[i];
            if (t5 != 0) {
                nused = nused3 + 1;
                c1[nused3] = t5;
            } else {
                nused = nused3;
            }
            i++;
            nused3 = nused;
        }
        return c1;
    }

    private int[] getPuzzle(int diff) {
        String puz;
        switch (diff) {
            case -1:
                puz = getPreferences(0).getString(PREF_PUZZLE, "360000000004230800000004200070460003820000014500013020001900000007048300000000045");
                break;
            case DIFFICULTY_EASY /*0*/:
            default:
                puz = easyPuzzle;
                break;
            case DIFFICULTY_MEDIUM /*1*/:
                puz = mediumPuzzle;
                break;
            case DIFFICULTY_HARD /*2*/:
                puz = hardPuzzle;
                break;
        }
        return fromPuzzleString(puz);
    }

    public String getTileString(int x, int y) {
        int v = getTile(x, y);
        if (v == 0) {
            return "";
        }
        return String.valueOf(v);
    }
    public void showKeypadOrError(int x, int y) {
        int[] tiles = getUsedTiles(x, y);
        if (tiles.length == 9) {
            Toast toast = Toast.makeText(this, (int) R.string.no_moves_label, Toast.LENGTH_SHORT);
            toast.setGravity(17, 0, 0);
            toast.show();
            return;
        }
        Log.d(TAG, "showKeypad: used=" + toPuzzleString(tiles));
        new Keypad(this, tiles, this.puzzleView).show();
    }

    public boolean setTileIfValid(int x, int y, int value) {
        int[] tiles = getUsedTiles(x, y);
        if (value != 0) {
            for (int tile : tiles) {
                if (tile == value) {
                    return false;
                }
            }
        }
        setTile(x, y, value);
        calculateUsedTiles();
        return true;
    }

    private static String toPuzzleString(int[] puz) {
        StringBuilder buf = new StringBuilder();
        for (int element : puz) {
            buf.append(element);
        }
        return buf.toString();
    }

    protected static int[] fromPuzzleString(String string) {
        int[] puz = new int[string.length()];
        for (int i = 0; i < puz.length; i++) {
            puz[i] = string.charAt(i) - '0';
        }
        return puz;
    }

    public int[] getUsedTiles(int x, int y) {
        return this.used[x][y];
    }

    private int getTile(int x, int y) {
        return this.puzzle[(y * 9) + x];
    }

    private void setTile(int x, int y, int value) {
        this.puzzle[(y * 9) + x] = value;
    }


    public void onResume() {
        super.onResume();
        Music.play(this, R.raw.game);
    }

    public void onPause() {
        super.onPause();
        Music.stop(this);
        getPreferences(0).edit().putString(PREF_PUZZLE, toPuzzleString(this.puzzle)).commit();
    }
}