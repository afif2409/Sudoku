package com.example.sudoku_game;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;

public class PuzzleView extends View {

    private static final int ID = 1; // Identifiant de context
    private static final String SELX = "selX";
    private static final String SELY = "selY";
    private static final String TAG = "Sudoku";
    private static final String VIEW_STATE = "viewState";
    private final Game game;
    private float height;
    private final Rect selRect = new Rect();
    private int selX; // Coordonnés X
    private int selY; // Coordonnés Y
    private float width;

    public PuzzleView(Context context) {
        super(context);
        this.game = (Game) context;
        setFocusable(true);
        setFocusableInTouchMode(true);
        setId(ID);
    }

    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        this.width = ((float) w) / 9.0f;
        this.height = ((float) h) / 9.0f;
        getRect(this.selX, this.selY, this.selRect);
        Log.d(TAG, "onSizeChanged: width " + this.width + ", height " + this.height);
        super.onSizeChanged(w, h, oldw, oldh);
    }

    private void getRect(int x, int y, Rect rect) {
        rect.set((int) (((float) x) * this.width), (int) (((float) y) * this.height), (int) ((((float) x) * this.width) + this.width), (int) ((((float) y) * this.height) + this.height));
    }

    public void onDraw(Canvas canvas) {
        Paint background = new Paint();
        background.setColor(getResources().getColor(R.color.background));
        canvas.drawRect(0.0f, 0.0f, (float) getWidth(), (float) getHeight(), background);
        Paint dark = new Paint();
        dark.setColor(getResources().getColor(R.color.puzzle_dark));
        dark.setStrokeWidth(0.8f);
        Paint hilite = new Paint();
        hilite.setColor(getResources().getColor(R.color.puzzle_dark));
        Paint light = new Paint();
        light.setColor(getResources().getColor(R.color.puzzle_dark));
        light.setStrokeWidth(0.8f);
        // Dessiner le grid du sudoku
          for (int i = 0; i < 9; i++) {
            canvas.drawLine(0.0f, ((float) i) * this.height, (float) getWidth(), ((float) i) * this.height, light);
            canvas.drawLine(0.0f, (((float) i) * this.height) + 1.0f, (float) getWidth(), (((float) i) * this.height) + 1.0f, hilite);
            canvas.drawLine(((float) i) * this.width, 0.0f, ((float) i) * this.width, (float) getHeight(), light);
            canvas.drawLine((((float) i) * this.width) + 1.0f, 0.0f, (((float) i) * this.width) + 1.0f, (float) getHeight(), hilite);
            }

        for (int i2 = 0; i2 < 9; i2++) {
            if (i2 % 3 == 0) {
                canvas.drawLine(0.0f, ((float) i2) * this.height, (float) getWidth(), ((float) i2) * this.height, dark);
                canvas.drawLine(0.0f, (((float) i2) * this.height) + 1.0f, (float) getWidth(), (((float) i2) * this.height) + 1.0f, hilite);
                canvas.drawLine(((float) i2) * this.width, 0.0f, ((float) i2) * this.width, (float) getHeight(), dark);
                canvas.drawLine((((float) i2) * this.width) + 1.0f, 0.0f, (((float) i2) * this.width) + 1.0f, (float) getHeight(), hilite);
            }
        }
        //Dessiner les numéros de la grille
        Paint paint = new Paint(1);
        paint.setColor(getResources().getColor(R.color.puzzle_hint_0));
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(this.height * 0.75f);
        paint.setTextScaleX(this.width / this.height);
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float x = this.width / 2.0f;
        float y = (this.height / 2.0f) - ((fm.ascent + fm.descent) / 2.0f);
        for (int i3 = 0; i3 < 9; i3++) {
            for (int j = 0; j < 9; j++) {
                canvas.drawText(this.game.getTileString(i3, j), (((float) i3) * this.width) + x, (((float) j) * this.height) + y, paint);
            }
        }
        /*if (Prefs.getHints(getContext())) {
            Paint hint = new Paint();
            int[] c = {getResources().getColor(R.color.puzzle_hint_0), getResources().getColor(R.color.puzzle_hint_1), getResources().getColor(R.color.puzzle_hint_2)};
           // int[] c = {Color.TRANSPARENT, Color.TRANSPARENT, Color.TRANSPARENT};
            Rect r = new Rect();
            for (int i4 = 0; i4 < 9; i4++) {
                for (int j2 = 0; j2 < 9; j2++) {
                    int movesleft = 9 - this.game.getUsedTiles(i4, j2).length;
                    if (movesleft < c.length) {
                        getRect(i4, j2, r);
                       // hint.setStyle(Paint.Style.STROKE);
                        hint.setColor(c[movesleft]);
                        //paint.setStyle(Paint.Style.STROKE);
                        canvas.drawRect(r, hint);
                    }
                }
            }
        }*/
        Log.d(TAG, "selRect=" + this.selRect);
        Paint selected = new Paint();
        selected.setStyle(Paint.Style.STROKE);
        selected.setColor(getResources().getColor(R.color.puzzle_selected));
        canvas.drawRect(this.selRect, selected);
    }
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != 0) {
            return super.onTouchEvent(event);
        }
        select((int) (event.getX() / this.width), (int) (event.getY() / this.height));
        this.game.showKeypadOrError(this.selX, this.selY);
        Log.d(TAG, "onTouchEvent: x " + this.selX + ", y " + this.selY);
        return true;
    }

    public void setSelectedTile(int tile) {
        if (this.game.setTileIfValid(this.selX, this.selY, tile)) {
            invalidate();
            return;
        }
        Log.d(TAG, "setSelectedTile: invalid: " + tile);
        startAnimation(AnimationUtils.loadAnimation(this.game, R.anim.shake));
    }

    private void select(int x, int y) {
        invalidate(this.selRect);
        this.selX = Math.min(Math.max(x, 0), 8);
        this.selY = Math.min(Math.max(y, 0), 8);
        getRect(this.selX, this.selY, this.selRect);
        invalidate(this.selRect);
    }

    public void onRestoreInstanceState(Parcelable state) {
        Log.d(TAG, "onRestoreInstanceState");
        Bundle bundle = (Bundle) state;
        select(bundle.getInt(SELX), bundle.getInt(SELY));
        super.onRestoreInstanceState(bundle.getParcelable(VIEW_STATE));
    }

    public Parcelable onSaveInstanceState() {
        Parcelable p = super.onSaveInstanceState();
        Log.d(TAG, "onSaveInstanceState");
        Bundle bundle = new Bundle();
        bundle.putInt(SELX, this.selX);
        bundle.putInt(SELY, this.selY);
        bundle.putParcelable(VIEW_STATE, p);
        return bundle;
    }
}
